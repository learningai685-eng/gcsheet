import { Injectable } from '@angular/core';
import { PocketbaseService } from './pocketbase.service';

@Injectable({
  providedIn: 'root'
})
export class GcsheetFitService {
  private pb = PocketbaseService.getInstance().getClient();

  async getAll(): Promise<any[]> {
    const cacheKey = 'gcsheet_fit_all';
    const cached = PocketbaseService.getInstance().getCached<any[]>(cacheKey);
    if (cached) return cached;

    const records = await PocketbaseService.getInstance().withRetry(async () => {
      return await this.pb.collection('egcsheet1_mstfit').getFullList({
        requestKey: null
      });
    });

    PocketbaseService.getInstance().setCache(cacheKey, records);
    return records;
  }

  async create(data: { name: string; pcsperpkt?: number }): Promise<{ success: boolean; record?: any; error: string }> {
    try {
      const record = await this.pb.collection('egcsheet1_mstfit').create(data);
      PocketbaseService.getInstance().invalidateCache('gcsheet_fit_all');
      return { success: true, record, error: '' };
    } catch (err: any) {
      return { success: false, record: null, error: err.message || 'Failed to create record' };
    }
  }

  async update(id: string, data: { name: string; pcsperpkt?: number }): Promise<{ success: boolean; record?: any; error: string }> {
    try {
      const record = await this.pb.collection('egcsheet1_mstfit').update(id, data);
      PocketbaseService.getInstance().invalidateCache('gcsheet_fit_all');
      return { success: true, record, error: '' };
    } catch (err: any) {
      return { success: false, record: null, error: err.message || 'Failed to update record' };
    }
  }

  async delete(id: string): Promise<boolean> {
    try {
      await this.pb.collection('egcsheet1_mstfit').delete(id);
      PocketbaseService.getInstance().invalidateCache('gcsheet_fit_all');
      return true;
    } catch (err: any) {
      return false;
    }
  }
}
