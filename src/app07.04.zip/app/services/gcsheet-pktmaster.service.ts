import { Injectable } from '@angular/core';
import { PocketbaseService } from './pocketbase.service';

@Injectable({
  providedIn: 'root'
})
export class GcsheetPktmasterService {
  private pb = PocketbaseService.getInstance().getClient();

  async getAll(): Promise<any[]> {
    const cacheKey = 'gcsheetpktmaster_all';
    const cached = PocketbaseService.getInstance().getCached<any[]>(cacheKey);
    if (cached) return cached;

    const records = await PocketbaseService.getInstance().withRetry(async () => {
      return await this.pb.collection('egcsheet1_pktmst').getFullList({
        requestKey: null
      });
    });

    PocketbaseService.getInstance().setCache(cacheKey, records);
    return records;
  }

  async search(term: string = ''): Promise<any[]> {
    if (!term) return this.getAll();

    try {
      const escapedTerm = term.replace(/"/g, '""');
      const records = await this.pb.collection('egcsheet1_pktmst').getFullList({
        filter: `pktname ~ "${escapedTerm}"`,
        requestKey: null
      });
      return records;
    } catch (err: any) {
      console.error('GcsheetPktmaster search error:', err);
      return [];
    }
  }

  async create(data: {
    cmpno?: string | null;
    mmno?: string | null;
    fitno?: string | null;
    nalino?: string | null;
    gradeno?: string | null;
    itemno?: string | null;
    pktname?: string;
    pktno?: number | null;
    status?: string;
  }): Promise<{ success: boolean; record?: any; error?: string }> {
    try {
      console.log('Creating pktmaster with data:', JSON.stringify(data, null, 2));
      const record = await this.pb.collection('egcsheet1_pktmst').create(data);
      PocketbaseService.getInstance().invalidateCache('gcsheetpktmaster_all');
      return { success: true, record };
    } catch (err: any) {
      console.error('Create error:', err);
      console.error('Error data:', JSON.stringify(err.data, null, 2));
      let errorMessage = 'Failed to create pktmaster record';

      if (err.status === 400 && err.data) {
        const data = err.data;
        if (data.data) {
          const fieldErrors = Object.keys(data.data).map(key => `${key}: ${data.data[key].message}`).join(', ');
          errorMessage = fieldErrors;
        } else {
          errorMessage = data.message || JSON.stringify(data);
        }
      } else if (err.message) {
        errorMessage = err.message;
      }

      console.error('Error message:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  async update(
    id: string,
    data: {
      cmpno?: string | null;
      mmno?: string | null;
      fitno?: string | null;
      nalino?: string | null;
      gradeno?: string | null;
      itemno?: string | null;
      pktname?: string;
      pktno?: number | null;
      status?: string;
    }
  ): Promise<{ success: boolean; record?: any; error?: string }> {
    try {
      const record = await this.pb.collection('egcsheet1_pktmst').update(id, data);
      PocketbaseService.getInstance().invalidateCache('gcsheetpktmaster_all');
      return { success: true, record };
    } catch (err: any) {
      let errorMessage = 'Failed to update pktmaster record';

      if (err.status === 400 && err.data?.data?.pktname) {
        errorMessage = 'Packet name already exists. Please use different values.';
      } else if (err.message) {
        errorMessage = err.message;
      }

      return { success: false, error: errorMessage };
    }
  }

  async delete(id: string): Promise<boolean> {
    try {
      await this.pb.collection('egcsheet1_pktmst').delete(id);
      PocketbaseService.getInstance().invalidateCache('gcsheetpktmaster_all');
      return true;
    } catch (err: any) {
      return false;
    }
  }

  async setAllActive(): Promise<boolean> {
    try {
      const records = await this.pb.collection('egcsheet1_pktmst').getFullList({
        fields: 'id',
        requestKey: null
      });

      await Promise.all(
        records.map(record => 
          this.pb.collection('egcsheet1_pktmst').update(record.id, { status: 'Active' })
        )
      );

      PocketbaseService.getInstance().invalidateCache('gcsheetpktmaster_all');
      return true;
    } catch (err: any) {
      console.error('Error setting all pktmaster active:', err);
      return false;
    }
  }

  async getMaxPktno(): Promise<number> {
    try {
      const records = await this.pb.collection('egcsheet1_pktmst').getFullList({
        fields: 'pktno',
        requestKey: null
      });
      
      if (records.length === 0 || records[0]['pktno'] === null || records[0]['pktno'] === undefined) {
        return 1;
      }
      
      return (records[0]['pktno'] as number) + 1;
    } catch (err: any) {
      console.error('Error getting max pktno:', err);
      return 1;
    }
  }
}
