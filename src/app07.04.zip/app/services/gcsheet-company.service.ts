import { Injectable } from '@angular/core';
import { PocketbaseService } from './pocketbase.service';

@Injectable({
  providedIn: 'root'
})
export class GcsheetCompanyService {
  private pb = PocketbaseService.getInstance().getClient();

  async getAll(): Promise<any[]> {
    const cacheKey = 'gcsheet_company_all';
    const cached = PocketbaseService.getInstance().getCached<any[]>(cacheKey);
    if (cached) return cached;

    const records = await PocketbaseService.getInstance().withRetry(async () => {
      return await this.pb.collection('egcsheet1_mstcmp').getFullList({
        requestKey: null
      });
    });

    PocketbaseService.getInstance().setCache(cacheKey, records);
    return records;
  }

  async create(data: { name: string }): Promise<{ success: boolean; record?: any; error?: string }> {
    try {
      const record = await this.pb.collection('egcsheet1_mstcmp').create(data);
      PocketbaseService.getInstance().invalidateCache('gcsheet_company_all');
      return { success: true, record };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create record' };
    }
  }

  async update(id: string, data: { name: string }): Promise<{ success: boolean; record?: any; error?: string }> {
    try {
      const record = await this.pb.collection('egcsheet1_mstcmp').update(id, data);
      PocketbaseService.getInstance().invalidateCache('gcsheet_company_all');
      return { success: true, record };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update record' };
    }
  }

  async delete(id: string): Promise<boolean> {
    try {
      await this.pb.collection('egcsheet1_mstcmp').delete(id);
      PocketbaseService.getInstance().invalidateCache('gcsheet_company_all');
      return true;
    } catch (err: any) {
      return false;
    }
  }
}
