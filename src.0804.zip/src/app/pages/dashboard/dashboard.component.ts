import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" (click)="navigateToDashboard()" style="cursor: pointer;">
          <i class="bi bi-grid-3x3-gap me-2"></i>
          GCSheet
        </a>
        <button class="navbar-toggler" type="button" (click)="isCollapsed = !isCollapsed">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" [class.show]="!isCollapsed" (click)="isCollapsed = true">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" (click)="navigateToDashboard()" style="cursor: pointer;">
                <i class="bi bi-speedometer2 me-1"></i> Dashboard
              </a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" style="cursor: pointer;" (click)="toggleGcsheetMenu()">
                <i class="bi bi-grid-3x3-gap me-1"></i> Gcsheet
              </a>
              <ul class="dropdown-menu" [class.show]="showGcsheetMenu">
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetCompany()">
                    <i class="bi bi-building me-2"></i>Company
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetFit()">
                    <i class="bi bi-rulers me-2"></i>Fit
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetMm()">
                    <i class="bi bi-box me-2"></i>MM
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetGrade()">
                    <i class="bi bi-bar-chart me-2"></i>Grade
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetItem()">
                    <i class="bi bi-box-seam me-2"></i>Item
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetNali()">
                    <i class="bi bi-geo-alt me-2"></i>Nali
                  </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetPktmaster()">
                    <i class="bi bi-collection me-2"></i>Packet Master
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetSaleinv()">
                    <i class="bi bi-receipt me-2"></i>Sale Invoice
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" (click)="navigateToGcsheetSalereport()">
                    <i class="bi bi-file-earmark-bar-graph me-2"></i>Sale Report
                  </a>
                </li>
              </ul>
            </li>
          </ul>
          
          <ul class="navbar-nav">
            <li class="nav-item">
              <span class="nav-link">
                <i class="bi bi-person-circle me-1"></i>
                {{ authService.user()?.email }}
              </span>
            </li>
            <li class="nav-item">
              <button class="btn btn-outline-light btn-sm" (click)="logout()">
                <i class="bi bi-box-arrow-right me-1"></i>
                Logout
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header bg-primary text-white">
              <h4 class="mb-0">
                <i class="bi bi-speedometer2 me-2"></i>
                Welcome, {{ authService.user()?.username || authService.user()?.email }}!
              </h4>
            </div>
            <div class="card-body">
              @if (authService.isSuperAdmin()) {
                <div class="alert alert-success">
                  <i class="bi bi-check-circle-fill me-2"></i>
                  Admin access granted
                </div>
              }
              
              <h5 class="card-title">GCSheet Dashboard</h5>
              <p class="card-text">Use the shortcuts below to manage GCSheet masters, sale invoices, and print-ready reports.</p>
              
              <div class="row mt-4">
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-primary">
                    <div class="card-body text-center">
                      <i class="bi bi-building text-primary" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Company</h5>
                      <p class="card-text">Maintain company records</p>
                      <button class="btn btn-primary btn-sm" (click)="navigateToGcsheetCompany()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-success">
                    <div class="card-body text-center">
                      <i class="bi bi-collection text-success" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Packet Master</h5>
                      <p class="card-text">Manage packet definitions</p>
                      <button class="btn btn-success btn-sm" (click)="navigateToGcsheetPktmaster()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-warning">
                    <div class="card-body text-center">
                      <i class="bi bi-box-seam text-warning" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Item Master</h5>
                      <p class="card-text">Manage sheet items</p>
                      <button class="btn btn-warning btn-sm" (click)="navigateToGcsheetItem()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-info">
                    <div class="card-body text-center">
                      <i class="bi bi-rulers text-info" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Fit</h5>
                      <p class="card-text">Manage fit definitions</p>
                      <button class="btn btn-info btn-sm" (click)="navigateToGcsheetFit()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-danger">
                    <div class="card-body text-center">
                      <i class="bi bi-box text-danger" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">MM</h5>
                      <p class="card-text">Manage MM sizes</p>
                      <button class="btn btn-danger btn-sm" (click)="navigateToGcsheetMm()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-secondary">
                    <div class="card-body text-center">
                      <i class="bi bi-bar-chart text-secondary" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Grade</h5>
                      <p class="card-text">Manage grade codes</p>
                      <button class="btn btn-secondary btn-sm" (click)="navigateToGcsheetGrade()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-dark">
                    <div class="card-body text-center">
                      <i class="bi bi-geo-alt text-dark" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Nali</h5>
                      <p class="card-text">Manage nali values</p>
                      <button class="btn btn-dark btn-sm" (click)="navigateToGcsheetNali()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <div class="card h-100 border-primary">
                    <div class="card-body text-center">
                      <i class="bi bi-receipt text-primary" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Sale Invoice</h5>
                      <p class="card-text">Create and print invoices</p>
                      <button class="btn btn-primary btn-sm" (click)="navigateToGcsheetSaleinv()">Open</button>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="card h-100 border-success">
                    <div class="card-body text-center">
                      <i class="bi bi-file-earmark-bar-graph text-success" style="font-size: 2.5rem;"></i>
                      <h5 class="card-title mt-3">Sale Report</h5>
                      <p class="card-text">Open invoice print report</p>
                      <button class="btn btn-success btn-sm" (click)="navigateToGcsheetSalereport()">Open</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .navbar {
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .card {
      border-radius: 1rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    .card-header {
      border-radius: 1rem 1rem 0 0 !important;
    }

    .card-title {
      font-weight: 600;
    }

    .nav-item.dropdown {
      position: relative;
    }

    .dropdown-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      z-index: 1000;
      min-width: 10rem;
      padding: 0.5rem 0;
      margin: 0.125rem 0 0;
      background-color: #fff;
      border-radius: 0.5rem;
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
      list-style: none;
    }

    .dropdown-menu.show {
      display: block;
    }

    .dropdown-item {
      display: block;
      width: 100%;
      padding: 0.625rem 1.5rem;
      clear: both;
      font-weight: 400;
      color: #212529;
      text-align: inherit;
      white-space: nowrap;
      background-color: transparent;
      border: 0;
      cursor: pointer;
    }

    .dropdown-item:hover {
      background-color: #f8f9fa;
      color: #0d6efd;
    }

    .dropdown-divider {
      height: 0;
      margin: 0.5rem 0;
      overflow: hidden;
      border-top: 1px solid #dee2e6;
    }

    .nav-link {
      cursor: pointer;
    }
  `]
})
export class DashboardComponent {
  authService = inject(AuthService);
  private router = inject(Router);

  isCollapsed = true;
  showGcsheetMenu = false;

  navigateToDashboard(): void {
    this.router.navigate(['/dashboard']);
  }

  navigateToGcsheetPktmaster(): void {
    this.router.navigate(['/gcsheet-pktmaster']);
  }

  navigateToGcsheetCompany(): void {
    this.router.navigate(['/gcsheet-company']);
  }

  navigateToGcsheetFit(): void {
    this.router.navigate(['/gcsheet-fit']);
  }

  navigateToGcsheetMm(): void {
    this.router.navigate(['/gcsheet-mm']);
  }

  navigateToGcsheetGrade(): void {
    this.router.navigate(['/gcsheet-grade']);
  }

  navigateToGcsheetItem(): void {
    this.router.navigate(['/gcsheet-item']);
  }

  navigateToGcsheetNali(): void {
    this.router.navigate(['/gcsheet-nali']);
  }

  navigateToGcsheetSaleinv(): void {
    this.router.navigate(['/gcsheet-saleinv']);
  }

  navigateToGcsheetSalereport(): void {
    this.router.navigate(['/gcsheet1-salereport']);
  }

  toggleGcsheetMenu(): void {
    this.showGcsheetMenu = !this.showGcsheetMenu;
  }

  logout(): void {
    this.authService.logout();
  }
}
