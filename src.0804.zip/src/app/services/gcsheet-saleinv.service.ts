import { Injectable } from '@angular/core';
import { PocketbaseService } from './pocketbase.service';

export interface SalesHeader {
  id: string;
  billno: number;
  billdate: string;
  customername: string;
  truckno: string;
}

export interface SalesDetail {
  id: string;
  billno: string;
  pktno: string;
  pktname?: string;
  qty: number;
  weight: number;
  rate: number;
  amount: number;
}

@Injectable({
  providedIn: 'root'
})
export class GcsheetSaleinvService {
  private pb = PocketbaseService.getInstance().getClient();

  private async ensureAuth() {
    await PocketbaseService.getInstance().authenticate();
  }

  async preAuthenticate() {
    await PocketbaseService.getInstance().authenticate();
  }

  async getSalesHeaderAll(): Promise<SalesHeader[]> {
    await this.ensureAuth();
    const res = await this.pb.collection('egcsheet1_salesmy')
      .getList(1, 200, { sort: '-created' });

    return res.items.map((r: any) => ({
      id: r.id,
      billno: +r.billno,
      billdate: r.billdate,
      customername: r.customername,
      truckno: r.truckno,
      transportation: r.transportation || '',
      wgtslipno: r.wgtslipno || '',
      loadslipno: r.loadslipno || '',
      narration: r.narration || '',
      totalpcs: r.totalpcs || 0,
      totalwgt: r.totalwgt || 0,
      nettamount: r.nettamount || 0
    }));
  }

  async getSalesDetailAll(): Promise<SalesDetail[]> {
    await this.ensureAuth();
    const res = await this.pb.collection('egcsheet1_saledet')
      .getList(1, 500, { sort: 'billno,srno' });

    return res.items.map((r: any) => ({
      id: r.id,
      billno: r.billno,
      pktno: r.pktno,
      qty: +r.qty || 0,
      weight: +r.weight || 0,
      rate: +r.rate || 0,
      amount: +r.amount || 0
    }));
  }

  async getSalesDetailByBillno(billno: string): Promise<SalesDetail[]> {
    await this.ensureAuth();
    // Use getList with pagination instead of getFullList for better performance
    const res = await this.pb.collection('egcsheet1_saledet').getList(1, 500, {
      filter: `billno="${billno}"`,
      sort: 'srno'
    });

    return res.items.map((r: any) => ({
      id: r.id,
      billno: r.billno,
      pktno: r.pktno,
      qty: +r.qty || 0,
      weight: +r.weight || 0,
      rate: +r.rate || 0,
      amount: +r.amount || 0
    }));
  }

  async deleteSalesDetailsByBillno(billno: string): Promise<boolean> {
    try {
      await this.ensureAuth();
      const details = await this.getSalesDetailByBillno(billno);
      if (details.length === 0) return true;
      
      for (const d of details) {
        await PocketbaseService.getInstance().withRetry(async () => {
          await this.pb.collection('egcsheet1_saledet').delete(d.id);
        });
      }
      
      return true;
    } catch {
      return false;
    }
  }

  async createSalesHeader(data: any) {
    await this.ensureAuth();
    return await this.pb.collection('egcsheet1_salesmy').create(data);
  }

  async updateSalesHeader(id: string, data: any) {
    await this.ensureAuth();
    return await this.pb.collection('egcsheet1_salesmy').update(id, data);
  }

  async deleteSalesHeader(id: string) {
    await this.ensureAuth();
    return await this.pb.collection('egcsheet1_salesmy').delete(id);
  }

  async createSalesDetailsBatch(details: any[], onProgress?: (done: number, total: number) => void) {
    await this.ensureAuth();
    
    const BATCH_SIZE = 400;
    
    for (let i = 0; i < details.length; i += BATCH_SIZE) {
      const chunk = details.slice(i, i + BATCH_SIZE);
      
      for (const d of chunk) {
        try {
          await PocketbaseService.getInstance().withRetry(async () => {
            await this.pb.collection('egcsheet1_saledet').create(d);
          });
        } catch (err) {
          console.error('Failed to create sales detail:', err);
        }
      }
      
      if (onProgress) {
        onProgress(Math.min(i + BATCH_SIZE, details.length), details.length);
      }
    }
  }

  async getMaxBillno(): Promise<number> {
    await this.ensureAuth();
    const res = await this.pb.collection('egcsheet1_salesmy')
      .getList(1, 1, { sort: '-billno' });

    if (res.items.length > 0) {
      return parseInt(res.items[0]['billno']) + 1;
    }
    return 1;
  }

  async getPktmasterAll(): Promise<any[]> {
    await this.ensureAuth();
    const res = await this.pb.collection('egcsheet1_pktmst')
      .getFullList({ sort: 'pktname' });

    return res;
  }

  async getMstfitAll(): Promise<any[]> {
    await this.ensureAuth();
    const res = await this.pb.collection('egcsheet1_mstfit')
      .getList(1, 200, { sort: 'name' });

    return res.items;
  }

}